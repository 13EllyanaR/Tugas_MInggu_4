package com.example.button

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
